﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace fink1_3
{
    /// <summary>
    /// Логика взаимодействия для prak10.xaml
    /// </summary>
    public partial class prak10 : Window
    {
        public prak10()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            prak101 Prak101 = new prak101();
            Prak101.Show();

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            prak102 Prak102 = new prak102();
            Prak102.Show();

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            prak111 Prak111 = new prak111();
            Prak111.Show();
            this.Close();

        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            prak103 Prak103 = new prak103();
            Prak103.Show();

        }
    }
}
