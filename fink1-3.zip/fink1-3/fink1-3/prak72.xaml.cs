﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace fink1_3
{
    /// <summary>
    /// Логика взаимодействия для prak72.xaml
    /// </summary>
    public partial class prak72 : Window
    {
        public prak72()
        {
            InitializeComponent();
            StartPulseAnimation();
        }

        private void StartPulseAnimation()
        {
            // Анимация смещения градиента (имитирует пульсацию)
            DoubleAnimation offsetAnimation = new DoubleAnimation
            {
                From = 0,
                To = 0.6,
                Duration = TimeSpan.FromSeconds(1),
                AutoReverse = true,
                RepeatBehavior = RepeatBehavior.Forever
            };

            // Анимация цвета центра (от красного к оранжевому и обратно)
            ColorAnimation colorAnimation = new ColorAnimation
            {
                From = Colors.Red,
                To = Colors.OrangeRed,
                Duration = TimeSpan.FromSeconds(1),
                AutoReverse = true,
                RepeatBehavior = RepeatBehavior.Forever
            };

            // Применяем анимации
            InnerStop.BeginAnimation(GradientStop.OffsetProperty, offsetAnimation);
            InnerStop.BeginAnimation(GradientStop.ColorProperty, colorAnimation);
        }
    }
}
