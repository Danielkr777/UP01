﻿using Microsoft.Win32;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;

namespace fink1_3
{
    public partial class prak112 : Window
    {
        public prak112()
        {
            InitializeComponent();
        }

        private void LoadImages_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog
            {
                Multiselect = true,
                Filter = "Изображения (*.jpg;*.jpeg;*.png;*.bmp)|*.jpg;*.jpeg;*.png;*.bmp"
            };

            if (dialog.ShowDialog() == true)
            {
                ImagesPanel.Children.Clear(); // Очистим старые

                foreach (string filePath in dialog.FileNames)
                {
                    ImagesPanel.Children.Add(CreateImageContainer(filePath));
                }
            }
        }

        private UIElement CreateImageContainer(string imagePath)
        {
            // Контейнер
            var border = new Border
            {
                Width = 200,
                Height = 200,
                Margin = new Thickness(10),
                Background = Brushes.White,
                CornerRadius = new CornerRadius(10),
                RenderTransformOrigin = new Point(0.5, 0.5),
                Cursor = System.Windows.Input.Cursors.Hand
            };

            var scaleTransform = new ScaleTransform(1, 1);
            var rotateTransform = new RotateTransform(0);
            var blurEffect = new BlurEffect { Radius = 5 };

            var transformGroup = new TransformGroup();
            transformGroup.Children.Add(scaleTransform);
            transformGroup.Children.Add(rotateTransform);
            border.RenderTransform = transformGroup;

            var image = new Image
            {
                Source = new BitmapImage(new Uri(imagePath)),
                Stretch = Stretch.UniformToFill,
                Effect = blurEffect
            };

            border.Child = image;

            // Наведение
            border.MouseEnter += (s, e) =>
            {
                AnimateScale(scaleTransform, 1.1);
                AnimateBlur(blurEffect, 0);
                border.Effect = (Effect)this.Resources["ShadowEffect"];
            };

            border.MouseLeave += (s, e) =>
            {
                AnimateScale(scaleTransform, 1.0);
                AnimateBlur(blurEffect, 5);
                border.Effect = null;
            };

            // Контейнер с кнопками
            var container = new StackPanel
            {
                Orientation = Orientation.Vertical,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };

            var rotateLeft = new Button { Content = "⟲", Width = 50, Margin = new Thickness(2) };
            var rotateRight = new Button { Content = "⟳", Width = 50, Margin = new Thickness(2) };

            rotateLeft.Click += (s, e) => rotateTransform.Angle -= 90;
            rotateRight.Click += (s, e) => rotateTransform.Angle += 90;

            var buttonPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 5, 0, 0)
            };

            buttonPanel.Children.Add(rotateLeft);
            buttonPanel.Children.Add(rotateRight);

            var finalPanel = new StackPanel();
            finalPanel.Children.Add(border);
            finalPanel.Children.Add(buttonPanel);

            return finalPanel;
        }

        private void AnimateScale(ScaleTransform scale, double to)
        {
            var animX = new DoubleAnimation(to, TimeSpan.FromMilliseconds(300));
            var animY = new DoubleAnimation(to, TimeSpan.FromMilliseconds(300));
            scale.BeginAnimation(ScaleTransform.ScaleXProperty, animX);
            scale.BeginAnimation(ScaleTransform.ScaleYProperty, animY);
        }

        private void AnimateBlur(BlurEffect blur, double to)
        {
            var anim = new DoubleAnimation(to, TimeSpan.FromMilliseconds(300));
            blur.BeginAnimation(BlurEffect.RadiusProperty, anim);
        }
    }
}