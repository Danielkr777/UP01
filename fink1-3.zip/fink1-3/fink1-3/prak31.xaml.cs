﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace fink1_3
{
    /// <summary>
    /// Логика взаимодействия для prak31.xaml
    /// </summary>
    public partial class prak31 : Window
    {
        private bool _isDrawing;
        private Point _startPoint;
        private Shape _currentShape;

        public prak31()
        {
            InitializeComponent();
        }



        // Помощник: получить Brush из ComboBox
        private Brush GetSelectedBrush()
        {
            if (ColorPicker.SelectedItem is ComboBoxItem item && item.Tag is string colorName)
                return (Brush)new BrushConverter().ConvertFromString(colorName);
            return Brushes.Black;
        }

        private void DrawingCanvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            _isDrawing = false;
            _currentShape = null;
            StatusText.Text = "Готово";
        }

        private void DrawingCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            {
                _startPoint = e.GetPosition(DrawingCanvas);

                if (rbDraw.IsChecked == true)
                {
                    // Начинаем новый эллипс
                    _currentShape = new Ellipse
                    {
                        Stroke = GetSelectedBrush(),
                        StrokeThickness = SizeSlider.Value
                    };
                    Canvas.SetLeft(_currentShape, _startPoint.X);
                    Canvas.SetTop(_currentShape, _startPoint.Y);
                    DrawingCanvas.Children.Add(_currentShape);
                    _isDrawing = true;
                    StatusText.Text = "Рисуем...";
                }
                else if (rbEdit.IsChecked == true)
                {
                    // Попробуем захватить ближайший примитив
                    HitTestResult hit = VisualTreeHelper.HitTest(DrawingCanvas, _startPoint);
                    if (hit?.VisualHit is Shape shape)
                    {
                        _currentShape = shape;
                        _isDrawing = true;
                        StatusText.Text = "Редактируем...";
                    }
                }
                else if (rbDelete.IsChecked == true)
                {
                    // Удаляем объект, если кликнули на нём
                    HitTestResult hit = VisualTreeHelper.HitTest(DrawingCanvas, _startPoint);
                    if (hit?.VisualHit is Shape shape)
                    {
                        DrawingCanvas.Children.Remove(shape);
                        StatusText.Text = "Удалено";
                    }
                }
            }

        }

        private void DrawingCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            {
                if (!_isDrawing) return;

                Point pos = e.GetPosition(DrawingCanvas);

                if (rbDraw.IsChecked == true && _currentShape is Ellipse ellipse)
                {
                    double x = Math.Min(pos.X, _startPoint.X);
                    double y = Math.Min(pos.Y, _startPoint.Y);
                    double w = Math.Abs(pos.X - _startPoint.X);
                    double h = Math.Abs(pos.Y - _startPoint.Y);
                    ellipse.Width = w;
                    ellipse.Height = h;
                    Canvas.SetLeft(ellipse, x);
                    Canvas.SetTop(ellipse, y);
                }
                else if (rbEdit.IsChecked == true && _currentShape != null)
                {
                    // Перемещение объекта
                    double dx = pos.X - _startPoint.X;
                    double dy = pos.Y - _startPoint.Y;
                    double left = Canvas.GetLeft(_currentShape) + dx;
                    double top = Canvas.GetTop(_currentShape) + dy;
                    Canvas.SetLeft(_currentShape, left);
                    Canvas.SetTop(_currentShape, top);
                    _startPoint = pos;
                }
            }

        }
    }
}
