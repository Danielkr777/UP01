﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace fink1_3
{
    public partial class AnimatedToggleButton : UserControl
    {
        private double _currentAngle = 0;

        public AnimatedToggleButton()
        {
            InitializeComponent();

            toggle.MouseEnter += (s, e) =>
            {
                var enlarge = new DoubleAnimation(1, 1.1, TimeSpan.FromMilliseconds(150));
                scaleTransform.BeginAnimation(System.Windows.Media.ScaleTransform.ScaleXProperty, enlarge);
                scaleTransform.BeginAnimation(System.Windows.Media.ScaleTransform.ScaleYProperty, enlarge);
            };

            toggle.MouseLeave += (s, e) =>
            {
                var shrink = new DoubleAnimation(1.1, 1, TimeSpan.FromMilliseconds(150));
                scaleTransform.BeginAnimation(System.Windows.Media.ScaleTransform.ScaleXProperty, shrink);
                scaleTransform.BeginAnimation(System.Windows.Media.ScaleTransform.ScaleYProperty, shrink);
            };

            toggle.Click += (s, e) =>
            {
                _currentAngle += 20;
                var rotate = new DoubleAnimation
                {
                    To = _currentAngle,
                    Duration = TimeSpan.FromMilliseconds(300),
                    EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
                };

                rotateTransform.BeginAnimation(System.Windows.Media.RotateTransform.AngleProperty, rotate);
            };
        }
    }
}
