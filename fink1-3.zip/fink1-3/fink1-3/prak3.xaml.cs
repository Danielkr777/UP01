﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace fink1_3
{
    /// <summary>
    /// Логика взаимодействия для prak3.xaml
    /// </summary>
    public partial class prak3 : Window
    {
        public prak3()
        {
            InitializeComponent();
        }


        private void RedBackground_Click(object sender, RoutedEventArgs e)
        {
            myay.Background = Brushes.Red;
        }

        private void GreenBackground_Click(object sender, RoutedEventArgs e)
        {
            myay.Background = Brushes.LightGreen;
        }

        private void BlueBackground_Click(object sender, RoutedEventArgs e)
        {
            myay.Background = Brushes.LightBlue;
        }

        private void About_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Разработчик: Иван Иванов\nВерсия: 1.0", "О программе");
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void MenuItem_MouseEnter(object sender, MouseEventArgs e)
        {
            if (sender is MenuItem item)
                StatusText.Text = $"Подсказка: {item.Header}";
        }

        private void ToolButton_MouseEnter(object sender, MouseEventArgs e)
        {
            if (sender is Button button)
                StatusText.Text = $"Кнопка: {button.Content}";
        }

        private void ClearStatus(object sender, MouseEventArgs e)
        {
            StatusText.Text = "Готово";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            prak31 Prak31 = new prak31();
            Prak31.Show();
            this.Close();

        }

        private void menuColorPicker_SelectedColorChanged(object sender, RoutedPropertyChangedEventArgs<Color?> e)
        {
            {
                if (menuColorPicker.SelectedColor.HasValue)
                {
                    myay.Background = new SolidColorBrush(menuColorPicker.SelectedColor.Value);
                }
            }

        }
    }
}
