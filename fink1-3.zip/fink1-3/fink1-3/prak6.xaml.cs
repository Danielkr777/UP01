﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace fink1_3
{
    /// <summary>
    /// Логика взаимодействия для prak6.xaml
    /// </summary>
    public partial class prak6 : Window
    {
        public prak6()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            prak61 Prak61 = new prak61();
            Prak61.Show();

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            prak62 Prak62 = new prak62();
            Prak62.Show();

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            prak77 Prak77 = new prak77();
            Prak77.Show();
            this.Close();

        }
    }
}
