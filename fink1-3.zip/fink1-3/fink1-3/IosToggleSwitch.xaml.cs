﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace fink1_3
{
    /// <summary>
    /// Логика взаимодействия для IosToggleSwitch.xaml
    /// </summary>
    public partial class IosToggleSwitch : UserControl
    {
        private double _currentAngle = 0;

        public IosToggleSwitch()
        {
            InitializeComponent();

            // Наведение — масштаб
            toggle.MouseEnter += (s, e) =>
            {
                AnimateScale(1.1);
            };

            toggle.MouseLeave += (s, e) =>
            {
                AnimateScale(1);
            };

            // Клик — поворот
            toggle.Click += (s, e) =>
            {
                _currentAngle += 20;
                var rotateAnim = new DoubleAnimation
                {
                    To = _currentAngle,
                    Duration = TimeSpan.FromMilliseconds(300),
                    EasingFunction = new SineEase { EasingMode = EasingMode.EaseOut }
                };

                var icon = toggle.Template.FindName("rotateIcon", toggle) as System.Windows.Media.RotateTransform;
                icon?.BeginAnimation(System.Windows.Media.RotateTransform.AngleProperty, rotateAnim);
            };
        }

        private void AnimateScale(double scale)
        {
            var scaleAnim = new DoubleAnimation(scale, TimeSpan.FromMilliseconds(150));
            scaleTransform.BeginAnimation(System.Windows.Media.ScaleTransform.ScaleXProperty, scaleAnim);
            scaleTransform.BeginAnimation(System.Windows.Media.ScaleTransform.ScaleYProperty, scaleAnim);
        }
    }
}
