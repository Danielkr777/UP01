﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace fink1_3
{
    /// <summary>
    /// Логика взаимодействия для prak111.xaml
    /// </summary>
    public partial class prak111 : Window
    {
        public prak111()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            prak11 Prak11 = new prak11();
            Prak11.Show();

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            prak112 Prak112 = new prak112();
            Prak112.Show();

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            prak12 Prak12 = new prak12();
            Prak12.Show();
            this.Close();

        }
    }
}
