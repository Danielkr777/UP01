﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace fink1_3
{
    /// <summary>
    /// Логика взаимодействия для prak5.xaml
    /// </summary>
    public partial class prak5 : Window
    {
        public prak5()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            prak6 Prak6 = new prak6();
            Prak6.Show();
            prak62 Prak62 = new prak62();
            this.Close();

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            prak53 Prak53 = new prak53();
            Prak53.Show();

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            prak52 Prak52 = new prak52();
            Prak52.Show();

        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            prak51 Prak51 = new prak51();
            Prak51.Show();

        }
    }
}
