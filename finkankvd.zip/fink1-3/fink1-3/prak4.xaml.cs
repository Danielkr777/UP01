﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace fink1_3
{
    /// <summary>
    /// Логика взаимодействия для prak4.xaml
    /// </summary>
    public partial class prak4 : Window
    {
        public prak4()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            prak41 Prak41 = new prak41();
            Prak41.Show();

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            prak42 Prak42 = new prak42();
            Prak42.Show();

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            prak5 Prak5 = new prak5();
            Prak5.Show();
            this.Close();

        }
    }
}
