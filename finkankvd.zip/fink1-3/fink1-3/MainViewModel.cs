﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace fink1_3
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private InkCanvasEditingMode _editingMode;
        public InkCanvasEditingMode EditingMode
        {
            get => _editingMode;
            set
            {
                _editingMode = value;
                OnPropertyChanged();
            }
        }

        public List<InkCanvasEditingMode> EditingModes { get; } = new List<InkCanvasEditingMode>
        {
            InkCanvasEditingMode.Ink,
            InkCanvasEditingMode.Select,
            InkCanvasEditingMode.EraseByPoint,
            InkCanvasEditingMode.EraseByStroke
        };

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
