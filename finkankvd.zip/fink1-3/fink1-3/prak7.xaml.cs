﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace fink1_3
{
    /// <summary>
    /// Логика взаимодействия для prak7.xaml
    /// </summary>
    public partial class prak7 : Window
    {
        public prak7()
        {
            InitializeComponent();
        }
            private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            ResetAllTextBoxes();

            var textBox = sender as TextBox;
            if (textBox != null)
            {
                textBox.Style = (Style)FindResource("LargeTextBoxStyle");
            }

        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            var textBox = sender as TextBox;
            if (textBox != null && !textBox.IsKeyboardFocused)
            {
                textBox.Style = (Style)FindResource("SmallTextBoxStyle");
            }

        }


        private void ResetAllTextBoxes()
        {
            foreach (var tb in GetAllTextBoxes(this))
            {
                tb.Style = (Style)FindResource("SmallTextBoxStyle");
            }
        }

        private IEnumerable<TextBox> GetAllTextBoxes(DependencyObject parent)
        {
            var list = new List<TextBox>();
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);
                if (child is TextBox textBox)
                    list.Add(textBox);
                else if (child is Panel panel)
                    list.AddRange(GetAllTextBoxes(panel));
                else if (child is ContentControl contentControl && contentControl.Content is DependencyObject depObj)
                    list.AddRange(GetAllTextBoxes(depObj));
            }
            return list;
        }

        private void TextBox_Loaded(object sender, RoutedEventArgs e)
        {
            if (sender is TextBox textBox)
            {
                var anim = (Storyboard)FindResource("StartupAnimation");
                Storyboard clone = anim.Clone();
                Storyboard.SetTarget(clone, textBox);
                clone.Begin();
            }
        }
    }
}
