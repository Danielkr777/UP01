﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace fink1_3
{
    /// <summary>
    /// Логика взаимодействия для prak71.xaml
    /// </summary>
    public partial class prak71 : Window
    {
        private Random random = new Random();

        public prak71()
        {
            InitializeComponent();
        }

        private void RunawayButton_MouseEnter(object sender, MouseEventArgs e)
        {
            double canvasWidth = MainCanvas.ActualWidth;
            double canvasHeight = MainCanvas.ActualHeight;

            double buttonWidth = RunawayButton.ActualWidth;
            double buttonHeight = RunawayButton.ActualHeight;

            // Вычисляем новые случайные координаты
            double newLeft = random.NextDouble() * (canvasWidth - buttonWidth);
            double newTop = random.NextDouble() * (canvasHeight - buttonHeight);

            // Устанавливаем новые координаты кнопки
            Canvas.SetLeft(RunawayButton, newLeft);
            Canvas.SetTop(RunawayButton, newTop);
        }
    }
}

