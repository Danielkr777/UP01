﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace fink1_3
{
    /// <summary>
    /// Логика взаимодействия для prak77.xaml
    /// </summary>
    public partial class prak77 : Window
    {
        public prak77()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            prak7 Prak7 = new prak7();
            Prak7.Show();

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            prak71 Prak71 = new prak71();
            Prak71.Show();

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            prak72 Prak72 = new prak72();
            Prak72.Show();

        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            prak8 Prak8 = new prak8();
            Prak8.Show();
            this.Close();

        }
    }
}
